
<h2>Abonos o facturas viejas</h2>
<table class="table table-striped">
    <thead>
      <tr>
        <th>Factura número</th>
        <th>Detalle</th>
        <th>Valor</th>
        <th>Fecha</th>
      </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $facturasAbonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php echo e($fac->metodo_pago); ?>

      <tr>
        <td><?php echo e($fac->numero_factura); ?></td>
        <td>Abono</td>
        
        <?php if($fac->metodo_pago === 'Tarjeta'): ?>
          <td class="sumas tarjeta"><?php echo e($fac->abono); ?></td>        
        <?php else: ?>
         <td class="sumas"><?php echo e($fac->abono); ?></td>
        <?php endif; ?>
       
        <td><?php echo e($fac->created_at->format('Y-m-d')); ?></td>

      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No existe información</p>
        <?php endif; ?>
      
    </tbody>
  </table>

<hr>

<h2>Saldos o facturas nuevas</h2>
<table class="table table-striped">
    <thead>
      <tr>
        <th>Factura número</th>
        <th>Detalle</th>
        <th>Valor</th>
        <th>Fecha</th>
      </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $facturasSaldos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
        <td><?php echo e($fac->numero_factura); ?></td>
        <td>Saldos</td>
         <?php if($fac->metodo_pago_saldo == 'Tarjeta'): ?>
          <td class="sumas tarjeta"><?php echo e($fac->saldo); ?></td>
         <?php else: ?>
         <td class="sumas"><?php echo e($fac->saldo); ?></td>
         <?php endif; ?>
        
        <td><?php echo e($fac->created_at->format('Y-m-d')); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No existe información</p>
        <?php endif; ?>
      
    </tbody>
  </table>

<hr>

<h2>Garantias</h2>
<table class="table table-striped">
    <thead>
      <tr>
       
        <th>Detalle</th>
        <th>Valor</th>
        <th>Fecha</th>
      </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $garantias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
       
        <td>Garantía</td>
        <td class="sumas"><?php echo e($fac->valor); ?></td>
        <td><?php echo e($fac->created_at->format('Y-m-d')); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>No existe información</p>
    <?php endif; ?>
      
    </tbody>
  </table>

<hr>

<h2>Recargos</h2>
<table class="table table-striped">
    <thead>
      <tr>       
        <th>Detalle</th>
        <th>Valor</th>
        <th>Fecha</th>
      </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $recargos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
       
        <td><?php echo e($fac->concepto); ?></td>
        <td class="sumas"><?php echo e($fac->valor); ?></td>
        <td><?php echo e($fac->created_at->format('Y-m-d')); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>No existe información</p>
    <?php endif; ?>
      
    </tbody>
  </table>
  <hr>
  <h2>Daños</h2>
<table class="table table-striped">
    <thead>
      <tr>       
        <th>Detalle</th>
        <th>Valor</th>
        <th>Fecha</th>
      </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $danios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
       
        <td><?php echo e($fac->concepto); ?></td>
        <td class="sumas"><?php echo e($fac->valor); ?></td>
        <td><?php echo e($fac->created_at->format('Y-m-d')); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>No existe información</p>
    <?php endif; ?>
      
    </tbody>
  </table>
  <hr>
  <h2>Salidas de caja</h2>
<table class="table table-striped">
    <thead>
      <tr>       
        <th>Detalle</th>
        <th>Valor</th>
        <th>Fecha</th>
        <th>Persona</th>
        <th>Identificación</th>
      </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
       
        <td><?php echo e($fac->concepto); ?></td>
        <td class="restas">- <?php echo e($fac->valor); ?></td>
        <td><?php echo e($fac->created_at->format('Y-m-d')); ?></td>
        <td><?php echo e($fac->nombre_persona); ?></td>
        <td><?php echo e($fac->identificacion); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>No existe información</p>
    <?php endif; ?>
      
    </tbody>
  </table>

  <h3>Total</h3>
  <span id="total"></span>
  <h3>Total Efectivo</h3>
  <span id="totalEfectivo"></span>
  <h3>Total Tarjeta</h3>
  <span id="totalTarjeta"></span>
  <?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
$(document).ready(function() {

})
</script>
<?php $__env->stopSection(); ?>



