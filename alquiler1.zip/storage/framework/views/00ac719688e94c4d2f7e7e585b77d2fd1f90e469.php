
<?php if(isset($productos) && count($productos)>= 1 && !is_null($productos)): ?>
<table class="table table-striped">
    <thead>
      <tr>
        
        <th>Producto</th>
        <th>Referencia</th>
        <th>Ajuste</th>
      </tr>
    </thead>
    
    <tbody>
    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
      <tr>

        <?php if(isset($producto->producto)): ?>        
        <td><?php echo e($producto->producto->nombre); ?></td>
        <td><?php echo e($producto->producto->referencia); ?></td>
        <?php else: ?>
        <td></td>
        <td></td>
        <?php endif; ?>
        <td><?php echo e($producto->ajustes); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php else: ?>
  No existen productos 
  <?php endif; ?>