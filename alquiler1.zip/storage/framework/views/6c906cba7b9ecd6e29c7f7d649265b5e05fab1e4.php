<?php $__env->startSection('content'); ?>
<div class="container"> 
  <div class="row">
    <div class="col-md-12">
      <div class="col-sm-6">
        <h2>Listado de productos</h2>
      </div>
      <div class="col-sm-6">
        <div class="text-right">
          <h2>
          <button id="btnCreateProveedor" type="button" class="btn btn-default">Crear proveedor</button>
          </h2>                
            </div>
        </div>        
      </div>
    </div>    
  </div>
          
  <table class="table table-striped ">
    <thead>
    <tr>
    <th>Nombre</th>
    <th>Nit</th>
    <th>No cuenta</th>
    <th>Banco</th>
    <th>Ciudad</th>    
    <th>Acciones</th>
    
    </tr>
    <?php if(count($proveedores) >= 1): ?>
      <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tbody>
      <tr>
          <td><?php echo e($prov->nombre); ?></td>
          <td><?php echo e($prov->nit); ?></td>
          <td><?php echo e($prov->cuenta); ?></td>
          <td><?php echo e($prov->ciudad); ?></td>
          <td><?php echo e($prov->banco); ?></td>
          
          <td><a href="<?php echo e(url('/proveedor/editar/'.$prov->id_proveedor)); ?>">Editar </a><br><a class="eliminarBtn" data-redirect="<?php echo e(url('/proveedor')); ?>" href="<?php echo e(url('/proveedor/eliminar/'.$prov->id_proveedor)); ?>"> Eliminar</a></td>        
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    No existen proveedores
    <?php endif; ?>
     
    </tbody>
  </table>
</div>

<div id="modalCreateProveedor" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Crear proveedor</h4>
      </div>
      <div class="modal-body">
      <form class="formsubmit" method="post" action="<?php echo e(url('/proveedor/crear')); ?>">
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="form-group">
          <label for="nombre">Nombre *</label>
          <input required type="text" class="form-control" name ="nombre">
        </div>
        <div class="form-group">
          <label for="nombre">Nit </label>
          <input  type="text" class="form-control" name ="nit">
        </div>
        <div class="form-group">
          <label for="nombre">Cuenta</label>
          <input type="number" class="form-control" name ="cuenta">
        </div>
        <div class="form-group">
          <label for="nombre">Banco</label>
          <input  type="text" class="form-control" name ="banco">
        </div>
        <div class="form-group">
          <label for="nombre">Ciudad</label>
          <input  type="text" class="form-control" name ="ciudad">
        </div>
        
       
        
        <button type="submit" class="btn btn-default">Crear</button>
      </form>
      </div>
    
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
$(document).ready(function() {

  $('#btnCreateProveedor').click(function(e){
    $('#modalCreateProveedor').modal('show')
  })

  $('form.formsubmit').submit(function(e){
    e.preventDefault();    
    var form = $(this);
    url = form.attr('action');
    method = form.attr('method');
    data = form.serialize();
   // $.post(url, $.param($(this).serializeArray()), function(data) {

    //});
    console.log(method, url)

    if(method == 'post'){
      $.post(url, data).done(function(data){
        if(data){
          alert('Se ha creado el proveedor exitosamente');
          $('#modalCreateProveedor').modal('hide');
          location.reload();

        }

      })
    }

  })

  $('.eliminarBtn').click(function(e){
    e.preventDefault();

    if(confirm('Está seguro que desea eliminar este registro?')){
      var url = $(this).attr('href');
      var urlredirect = $(this).attr('data-redirect');
      
      $.get(url).done(function(data){
        if(data){
        
          window.location.href = urlredirect;
        }
      })
    }

  })
    
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>