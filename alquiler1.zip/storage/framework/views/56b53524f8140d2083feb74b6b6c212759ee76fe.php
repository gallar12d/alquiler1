<?php $__env->startSection('content'); ?>
<div class="col-md-10 col-md-offset-1">

    <h3>Compromiso</h3>
    <table class="table table-striped ">
    <thead>
    <tr>
    <th>#Factura</th>
    <th>Fecha compromiso</th>
    <th>Fecha devolucioón</th>
    <th>Cliente</th>
    <th>Teléfono</th>    
    <th>Celular</th>     
    </tr>    
    <tbody>
      <tr>      
        <td><?php echo e($compromiso->factura->numero_factura); ?></td>          
          <td><?php echo e($compromiso->fecha_compromiso); ?></td>
          <td><?php echo e($compromiso->fecha_devolucion); ?></td>
          <td><?php echo e($compromiso->persona->name); ?></td>
          <td><?php echo e($compromiso->persona->telefono); ?></td>
          <td><?php echo e($compromiso->persona->celular); ?></td>          
        </tr>
    </tbody>
  </table>

    <hr />
    <?php if(isset($productos) && count($productos)>= 1 && !is_null($productos)): ?>
    <h3>Productos</h3>
    <table class="table table-striped">
        <thead>
        <tr>
            
            <th>Producto</th>
            <th>Referencia</th>
            <th>Ajuste</th>
        </tr>
        </thead>
        
        <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>

            <?php if(isset($producto->producto)): ?>        
            <td><?php echo e($producto->producto->nombre); ?></td>
            <td><?php echo e($producto->producto->referencia); ?></td>
            <?php else: ?>
            <td></td>
            <td></td>
            <?php endif; ?>
            <td><?php echo e($producto->ajustes); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    No existen productos 
    <?php endif; ?>
    <hr />
    <form class="formsubmit" method="post" action="<?php echo e(url('/compromiso/devolucion')); ?>">
        <input id="token" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input  type="hidden" name="id_factura" value="<?php echo e($factura->id_factura); ?>">
        <input  type="hidden" name="id_compromiso" value="<?php echo e($compromiso->id_compromiso); ?>">
        
        <div class="form-group col-md-6 ">
            <label for="nombre">Valor total</label>
            <input   value = "<?php echo e($factura->valor); ?>"  type="number" class="form-control"  name ="valor" disabled>
        </div>  
           
        <div class="form-group col-md-6 ">
            <label for="nombre">Abono </label>
            <input   value = "<?php echo e($factura->abono); ?>"  type="number" class="form-control"  name ="abono" disabled>
        </div> 
        <div class="form-group col-md-6 ">
            <label for="nombre">Depósito del Saldo</label>
            <input disabled id="deposito_saldo"  type="number" class="form-control" value="<?php echo e($factura->saldo); ?>"  name ="deposito_saldo" >
        </div> 
        <div class="form-group col-md-6">
          <label for="nombre">Prenda en buenas condiciones</label>
          <select id="malas_condiciones" class="form-control" name = 'malas_condiciones' >
          <option value="si">Sí</option>  
            <option value="no">No</option>          
                           
          </select>
        </div> 
        <div class="form-group col-md-6">
            <label for="comment">Estado y condiciones del producto</label>
            <textarea  disabled class="form-control"  id="condiciones" name ="condiciones"></textarea>
        </div>
        <div class="form-group col-md-6 ">
            <label for="nombre">Valor del daño</label>
            <input disabled id="valor_danio"  type="number" class="form-control"   name ="valor_danio" >
        </div> 
        <div class="form-group col-md-6 ">
            <label for="nombre"><?php echo e($textrecargo); ?></label>
            <input readonly id="recargo"  type="number" class="form-control"  value="<?php echo e($recargo); ?>" name ="recargo" >
        </div> 
        <div class="row">
            <div class ="col-md-12">               
                <button type ="submit"  class=" pull-right col-md-3 btn btn-default ">Hacer devolución</button>
            </div>  

        </div> 
        <br>

    </form>
    <br>
</div>

<!-- Modal agregar productos-->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function () {
      $(document).on('change', 'select#malas_condiciones', function(){

          
          if($(this).val() == 'no'){

           $('textarea#condiciones').prop('disabled', false);
           $('textarea#condiciones').attr('disabled', false); 
           $('input#valor_danio').prop('disabled', false);
           $('input#valor_danio').attr('disabled', false); 

     
          }
          else{
            $('textarea#condiciones').prop('disabled', true);
           $('textarea#condiciones').attr('disabled', true); 
           $('input#valor_danio').prop('disabled', true);
           $('input#valor_danio').attr('disabled', true); 
          }
      })
       
    })

   

   
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>