<?php

namespace App\Http\Controllers;

use App\Producto;
use App\Proveedor;
use App\Persona;
use App\Garantia;
use App\Entrada;
use App\Salida;
use App\Factura;
use App\Compromiso;
use App\CompromisoProducto;
use App\ConsecutivoFactura;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use DateTime;

class CompromisoController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct() {
        $this->middleware('auth');
    }

    public function index() {
        $compromisos = Compromiso::all();
        return view('compromiso.index', compact('compromisos'));
    }

    public function postFiltrar(Request $data) {
        $fechaInicial = $data->input('fechaInicio');
        $fechaFin = $data->input('fechaFin');
        $compromisos = Compromiso::where('fecha_compromiso', '>=', $fechaInicial)->where('fecha_compromiso', '<=', $fechaFin)->get();
        return view('compromiso.index', compact('compromisos'));
    }

    public function create() {
        return view('compromiso.create');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function crear(Request $data) {
        $fecha_compromiso = $data->input('fecha_compromiso');
        $fecha_devolucion = $data->input('fecha_devolucion');
        $abono = $data->input('abono');
        $tipo_pago = $data->input('tipo_pago');
        $saldo = $data->input('saldo');
        $id_cliente = $data->input('id_cliente');
        $productos = $data->input('productos');
        $banderaCompromiso = false;

        //verificar las fechas de cada producto si es que estan comprometidos y ver si se puede 

        foreach ($productos as $producto) {
            $id = $producto[0];

            $tieneCompromisos = CompromisoProducto::where('id_producto', $id)->get();
            if (count($tieneCompromisos)) {

                foreach ($tieneCompromisos as $compro) {
                    $compromiso = Compromiso::find($compro->id_compromiso);
                    $fechaDevol = $compromiso->fecha_devolucion;
                    //comparar cada fecha de devolución con la fecha nueva de compromiso tiene que estar con mas de 4 dias
                    if ($fechaDevol >= $fecha_compromiso) {
                        return 500;
                    } else if ($fechaDevol < $fecha_compromiso) {

                        $date1 = new DateTime($fechaDevol);
                        $date2 = new DateTime($fecha_compromiso);
                        $interval = $date1->diff($date2);
                        $interval = intval($interval->d);
                        if ($interval <= 3) {

                            return 500;
                        }
                    }
                }
            }
        }



        $compromiso = new Compromiso;
        $compromiso->fecha_compromiso = $fecha_compromiso;
        $compromiso->fecha_devolucion = $fecha_devolucion;
        $compromiso->estado = 'Creado';
        $compromiso->cedula = $id_cliente;

        if ($compromiso->save()) {
            $banderaCompromiso = true;
        }

        if ($banderaCompromiso) {
            $id_compromiso = $compromiso->id_compromiso;

            //crear los compromisos_productos
            $concepto = 'Compromiso de productos: ';

            foreach ($productos as $producto) {
                $compromisoProducto = new CompromisoProducto;
                $compromisoProducto->id_producto = $producto[0];
                $compromisoProducto->ajustes = $producto[1];
                $compromisoProducto->id_compromiso = $id_compromiso;
                $compromisoProducto->save();
                //cambiar estado al producto
                $producto = Producto::find($producto[0]);
                $concepto = $concepto . $producto->nombre . ', ';
                $producto->estado = 'Comprometido';
                $producto->save();
            }

            //crar la factura
            if ($banderaCompromiso) {
                $factura = new Factura;
                $factura->cedula = $id_cliente;
                $factura->valor = intval($abono) + intval($saldo);
                $factura->saldo = $saldo;
                $factura->abono = $abono;
                $factura->estado = 'Pendiente';
                $factura->metodo_pago = $tipo_pago;
                //obtener el consecutivo y aumentarlo mas 1 cuando se genere una factura nueva
                $consecutivoFactura = ConsecutivoFactura::find(1);
                if ($factura->save()) {
                    $facturamodificar = Factura::find($factura->id_factura);
                    $facturamodificar->numero_factura = $consecutivoFactura->numero;

                    $numeroFactura = $consecutivoFactura->numero;
                    $consecutivoFactura->numero = $consecutivoFactura->numero + 1;
                    $consecutivoFactura->save();
                    $facturamodificar->save();

                    $compromisoModificar = Compromiso::find($id_compromiso);
                    $compromisoModificar->id_factura = $factura->id_factura;
                    if ($compromisoModificar->save()) {

                        $url = url('/compromiso');
                        $factura = $numeroFactura;
                        $cliente = $id_cliente;
                        $valorTotal = intval($abono) + intval($saldo);
                        $valorAbono = intval($abono);
                        $valorSaldo = intval($saldo);
                        $fecha = date("Y-m-d");
                        $this->crearRecibo($url, $factura, $cliente, $valorTotal, $valorAbono, $valorSaldo, $fecha, $concepto);
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }

    public function crearRecibo($url, $factura, $cliente, $valorTotal, $valorAbono, $valorSaldo, $fecha, $concepto) {
        $phpWord = new \PhpOffice\PhpWord\PhpWord();
        $section = $phpWord->addSection();
        $text = $section->addText('Factura No: ' . $factura);
        $text = $section->addText('Valor factura: ' . $valorTotal);
        $text = $section->addText('Valor abono: ' . $valorAbono);
        $text = $section->addText('Valor saldo: ' . $valorSaldo);
        $text = $section->addText('Concepto: ' . $concepto);
        $text = $section->addText('Cliente: ' . $cliente);
        $text = $section->addText('Fecha: ' . $fecha);
//        $section->addImage("./images/Krunal.jpg");
        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
        if (file_exists(public_path('Recibo.docx'))) {
            unlink(public_path('Recibo.docx'));
        }

        $objWriter->save('Recibo.docx');
        echo 200;
        return 200;
    }

    public function eliminar($id) {
        $compromiso = Compromiso::find($id);

        $productosCompromiso = CompromisoProducto::where('id_compromiso', $id)->get();

        if (count($productosCompromiso) >= 1 && !is_null($productosCompromiso) && isset($productosCompromiso)) {
            foreach ($productosCompromiso as $producto) {
                $productoModificar = Producto::find($producto->id_producto);
                $productoModificar->estado = 'Disponible';
                $productoModificar->save();
            }
        }
        $productosCompromiso = CompromisoProducto::where('id_compromiso', $id);
        $productosCompromiso->delete();
        $facturamodificar = Factura::find($compromiso->id_factura);

        if ($compromiso->delete()) {

            //buscar factura y borrarla 
            $facturamodificar->estado = 'Anulada';
            $facturamodificar->save();
            $facturamodificar->delete();

            $consecutivoFactura = ConsecutivoFactura::find(1);
            $consecutivoFactura->numero = $consecutivoFactura->numero - 1;
            $consecutivoFactura->save();

            echo true;
        }
    }

    public function detalle($id_compromiso) {

        $productos = CompromisoProducto::where('id_compromiso', $id_compromiso)->get();
        return view('compromiso.detalle', compact('productos'));
    }

    public function entregar($id) {

        $productos = CompromisoProducto::where('id_compromiso', $id)->get();
        $compromiso = Compromiso::find($id);
        $factura = Factura::find($compromiso->id_factura);
        return view('compromiso.entrega', compact('productos', 'compromiso', 'factura'));
    }

    public function penalizar($id) {

        $productos = CompromisoProducto::where('id_compromiso', $id)->get();
        $compromiso = Compromiso::find($id);
        $factura = Factura::find($compromiso->id_factura);
        return view('compromiso.penalizar', compact('productos', 'compromiso', 'factura'));
    }

    public function devolver($id) {

        $productos = CompromisoProducto::where('id_compromiso', $id)->get();
        $compromiso = Compromiso::find($id);
        $factura = Factura::find($compromiso->id_factura);

        //calcular recargo

        $fecha_devolucionPactada = strtotime($compromiso->fecha_devolucion);

        $fechaHoy = strtotime(date('y-m-d'));
        $recargo = NULL;
        $textrecargo = 'Recargo';

        if ($fechaHoy > $fecha_devolucionPactada) {
            //calcular diferencia de dias 

            $datetime1 = date_create($compromiso->fecha_devolucion);
            $datetime2 = date_create(date('y-m-d'));
            $interval = date_diff($datetime1, $datetime2);

            $interval = $interval->format('%a');

            $porcentaje = ( intval($factura->valor) * 5) / 100;

            $recargo = $porcentaje * $interval;
            $textrecargo = 'Recargo por: ' . $interval . ' días.';
        }


        return view('compromiso.devolucion', compact('productos', 'compromiso', 'factura', 'recargo', 'textrecargo'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function postPenalizar(Request $request) {
        $compromisoModificar = Compromiso::find($request->id_compromiso);
        $compromisoModificar->estado = 'Penalizado';
        $compromisoModificar->save();
        $facturaModificar = Factura::find($request->id_factura);
        $valor_devolucion = intval($request->input('valor_devolucion'));

        if ($valor_devolucion == 0) {
            return redirect('compromiso');
        }
        $persona = Persona::where('cedula', $compromisoModificar->cedula)->first();
        $salida = new Salida;
        $salida->concepto = 'Penalización compromiso con factura no: ' . $facturaModificar->numero_factura;
        $salida->valor = $valor_devolucion;
        $salida->nombre_persona = $persona->name;
        $salida->identificacion = $persona->cedula;

        if ($salida->save()) {
            return redirect('compromiso');
        }
    }
    
    public function ajustar($id_compromiso = NULL, $option = NULL){
        
        $compromisoModificar = Compromiso::find($id_compromiso);
        if($option == 'a'){
            $compromisoModificar->ajustado = 1; 
            $compromisoModificar->save();
            return 200;
        }
        else if($option == 'd'){
             $compromisoModificar->ajustado = 0; 
             $compromisoModificar->save();
             return 200;
        }
    }

    public function postEntregar(Request $request) {

        $facturaModificar = Factura::find($request->id_factura);
        $facturaModificar->estado = 'Pagada';
        $facturaModificar->fecha_pago = date('y-m-d');
        $facturaModificar->metodo_pago_saldo = $request->tipo_pago;
        $facturaModificar->save();

        $compromisoModificar = Compromiso::find($request->id_compromiso);
        $garantia = new Garantia;
        $garantia->tipo_garantia = $request->tipo_garantia;
        if (!is_null($request->valor_garantia)) {
            $garantia->valor = $request->valor_garantia;
            $garantia->fecha_pago = date('y-m-d');
        }
        $garantia->save();

        $compromisoModificar->id_garantia = $garantia->id_garantia;
        $compromisoModificar->estado = 'Entregado';
        if ($compromisoModificar->save()) {
            return redirect('compromiso');
        }
    }

    public function postDevolucion(Request $request) {



        $compromisoModificar = Compromiso::find($request->id_compromiso);
        $compromisoModificar->estado = 'Devuelto';
        $compromisoModificar->buen_estado = $request->malas_condiciones;
        if (isset($request->condiciones) && !is_null($request->condiciones)) {
            $compromisoModificar->condiciones_entrega = $request->condiciones;
        }
        if (isset($request->valor_danio) && !is_null($request->valor_danio)) {
            $nuevaentrada = new Entrada;
            $nuevaentrada->concepto = 'Pago por daños de compromiso con factura No ' . $compromisoModificar->factura->numero_factura;
            $nuevaentrada->valor = $request->valor_danio;
            $nuevaentrada->tipo = 'Daños';
            $nuevaentrada->save();
        }
        if (!is_null($request->recargo)) {
            $nuevaentrada = new Entrada;
            $nuevaentrada->concepto = 'Recargo por demora de entrega de compromiso con factura No  ' . $compromisoModificar->factura->numero_factura;
            $nuevaentrada->valor = $request->recargo;
            $nuevaentrada->tipo = 'Recargo';
            $nuevaentrada->save();
        }



        if ($compromisoModificar->save()) {
            return redirect('compromiso');
        }
    }

}
