<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    //
    protected $table = 'producto';
    protected $fillable = [ 'nombre', 'talla', 'color', 'referencia', 'estado', 'valor', 'foto', 'linea', 'id_proveedor', 'fecha_entrega', 'fecha_devolucion'];
    protected $guarded = ['id'];
    protected $primaryKey = 'id';

    public function proveedor()
    {
        return $this->hasOne('App\Proveedor', 'id_proveedor', 'id_proveedor');
    }

   
}
