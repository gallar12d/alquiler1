<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Proveedor extends Model
{
    //
    protected $table = 'proveedor';
    protected $fillable = [ 'nombre', 'nit', 'cuenta', 'banco', 'ciudad'];
    protected $guarded = ['id_proveedor'];

    protected $primaryKey = 'id_proveedor';
}
